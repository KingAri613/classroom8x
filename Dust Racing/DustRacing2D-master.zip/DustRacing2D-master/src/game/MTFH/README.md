MTFH (Menu Toolkit From Hell) is a graphics agnostic model toolkit
designed for simple game menus. The user implements needed views for
the menu items. The toolkit is written in C++ and doesn't depend
on anything else but STL. It's quite painful to use :)

-- Jussi Lind <jussi.lind@iki.fi>
