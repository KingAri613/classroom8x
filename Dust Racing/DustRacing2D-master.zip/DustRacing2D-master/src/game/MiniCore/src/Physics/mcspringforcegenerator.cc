// This file belongs to the "MiniCore" game engine.
// Copyright (C) 2010 Jussi Lind <jussi.lind@iki.fi>
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
// MA  02110-1301, USA.
//

#include "mcspringforcegenerator.hh"
#include "mcobject.hh"
#include "mcphysicscomponent.hh"

MCSpringForceGenerator::MCSpringForceGenerator(MCObject & object2, float coeff, float length)
  : m_object2(object2)
  , m_coeff(coeff)
  , m_length(length)
{
}

void MCSpringForceGenerator::updateForce(MCObject & object1)
{
    object1.physicsComponent().preventSleeping(true);

    // Take diff vector of the node locations
    MCVector3dF diff = object1.location() - m_object2.location();

    // Get length of diff and normalize
    const float length = diff.length();
    if (length > 0)
    {
        diff /= length;
    }

    // Update force
    diff *= (m_length - length) * m_coeff;
    object1.physicsComponent().addForce(diff);

    if (m_object2.physicsComponent().isSleeping())
    {
        m_object2.physicsComponent().toggleSleep(false);
    }
}

MCSpringForceGenerator::~MCSpringForceGenerator() = default;
